#ifndef IAN_INCLUDE_H
#define IAN_INCLUDE_H
#include<iostream>
char LineAchar(void);
bool YesOrNo(const char * msg);
bool EnterQ(void);
#endif // IAN_INCLUDE_H
